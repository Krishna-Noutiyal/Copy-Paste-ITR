// background.js
// This file is required for the extension's service worker (background tasks).
// Currently, no background logic is needed, but this file is necessary for manifest v3.

chrome.runtime.onInstalled.addListener(() => {
  // Extension installed or updated
});